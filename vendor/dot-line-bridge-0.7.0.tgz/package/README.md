# dot-line-bridge

[English](README.en.md)

把本人发给 LINE Official Account 的私聊接到原来的 ChatGPT dot，并把 dot 的回答发回原私聊。通过官方 Secure MCP Tunnel 接入 dot，共享服务由 `dot-bridge-core` 提供，总仓库统一管理。

需要 LINE Messaging API channel、已有的 channel access token 和 channel secret，以及一个公网 HTTPS webhook 地址。MCP 端口和内部 webhook 接收端口都只监听本机。

支持文字收发，并可按需读取本人发送的图片、语音和文件，每个附件最多 5 MiB。语音能否直接播放或转写，取决于共享语音组件和当前 dot 的支持。只读取 LINE 自身提供的附件，外部托管内容、贴图和位置暂时只提供类型信息。不支持个人 LINE 账号登录或群聊。

LINE 的回复 token 单次有效且时间很短，dot 需要在收到消息后约 55 秒内提交最终回答；过期后不会自动改成主动推送。文字回答最多 20,000 字符，会在同一次回复请求内分块。

可选的[短期媒体托管](docs/media-hosting.md)可以让 dot 回复 JPEG／PNG 图片、M4A 音频和说明文字。它需要单独批准的 HTTPS 域名、独立上传密钥和托管配置，默认不启用。未配置时继续使用文字，程序不会自动公开附件或打开公网端口。LINE 不提供通用文件消息发送。

[配置与运行](docs/setup.md) · [统一安装入口](https://github.com/Arcueid77/dot-bridge) · [开发说明](docs/development.md)

配置好媒体下载入口后，也可以让 dot 把收到的图片或音频直接发回原私聊，文件由桥按附件编号读取，不需要来回传递很长的编码文本。LINE 仍不支持通用文件回复。

TXT、Markdown、JSON、CSV 等文本附件会提供可读的文字摘录，支持 UTF-8 和带标记的 UTF-16；过长时会明确标记为截断，原文件仍可读取。受保护的 Linux 处理环境可为 PDF／Office 提供有界摘录；原件继续保留。

运行主机可使用持续开机的 Linux 或 Windows 电脑，Linux 支持 systemd。macOS 尚未验证，欢迎试用并反馈。

## 定时消息

新增主动文字和固定提醒：目标只允许已绑定的本人私聊，主动发送默认关闭。管理员批准后可设置 `DOT_BRIDGE_OUTBOUND=owner-text`；原 dot 通过发送、保存提醒、查询、修改和取消工具管理，不需要重建事件订阅。每条最多 2,000 字符，重复提醒需有结束日期。

详见[定时消息使用指南](https://github.com/Arcueid77/dot-bridge/blob/main/docs/scheduled-messages.md)。

## 选项、文件和提醒管理

支持用编号文字回复一组选项，直接回复编号即可继续对话。生成的图片、音频或文件可由具备程序文件读取能力的原 dot 分块上传，经大小与 SHA-256 校验后作为原消息的最终回复。单文件上限 5 MiB，仍需满足本渠道支持的媒体类型与格式。

固定文字提醒支持工作日、固定间隔、暂停、恢复和发送历史。先核对 `check_line_outbound` 的开关，再按提醒编号与当前版本操作。暂停期间的旧时间点在恢复时跳过。


## 长任务、连续消息与语音

长任务开始时，dot 可调用任务工具取得编号、被动回复截止时间及剩余秒数，再保存完整结果。本人在原私聊发送 `/tasks` 查看编号，用 `/result 编号` 读取已保存的文字。结果按原消息保留期清除。发送结果不明时保留 uncertain，已完成的回复沿用原记录。

受保护交互配置支持 `queue`，例如 `{"mode":"batch","window_ms":750,"max_messages":5}`。`mode` 可选 `independent`、`serial`、`batch`，默认 independent。合并保留每条来源，并以最后一条为回复锚点。附件、引用、已开始处理的来源各自处理，会话与成员范围沿用原隔离规则。

Linux 管理员可安装本地 eSpeak NG 和受保护音频环境，配置 `DOT_BRIDGE_SPEECH_SYNTHESIS=local-espeak`、`DOT_BRIDGE_SPEECH_VOICE=zh`。原 dot 使用 `check_line_speech` 和 `reply_line_speech`，单次最多 2000 字符、120 秒。完整文字同时保存在任务记录里。

平台明确拒绝的一次性主动发送，可在本人确认后通过 `retry_line_outbound` 重试同一编号和当前版本。主动发送开关继续按渠道配置，重复提醒保持原来的编辑和恢复流程。原 dot 任务的停止、重置和审批通过原平台管理。

## 处理提示和快捷操作

本人私聊处理期间可显示原生加载动画。快捷按钮提供帮助、状态、队列和订阅查询。原生选择通过签名 postback 绑定本人、原会话和唯一选择结果，重复点击沿用首次结果。回复仍需在平台 reply token 的约 55 秒期限内完成；超过期限的完整结果可在任务工具或本人新发的 `/result` 请求中读取。语音合成使用 MP3，需已配置获准的媒体托管入口。
