import { assertLiveStorage } from './live-storage.js';
import { tunnelReadiness, tunnelLive, assertTunnelServiceConfig } from './tunnel-service-auth.js';
import http from 'node:http';
import { TextDecoder } from 'node:util';
import { Bridge } from './bridge.js';
import { BridgeError, object, rpcResult } from './common.js';
import {MEDIA_RPC_LIMIT} from '@dot-bridge/core/channels/media.js';
import { createAuthenticator } from './auth.js';
import { makePublicRequester } from './network.js';
import { createLarkRuntime } from './lark-runtime.js';

const VERSION = '2026-07-28';
function json(res, status, value, headers = {}) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff', ...headers });
  res.end(JSON.stringify(value));
}
async function readBody(req) {
  const limit=req.headers['mcp-name']==='reply_lark_media'?MEDIA_RPC_LIMIT:['reply_to_lark','append_lark_reply'].includes(req.headers['mcp-name'])?262144:32768;
  if (!/^application\/json(?:\s*;|$)/i.test(req.headers['content-type'] ?? '')) throw new BridgeError('Expected application/json', { status: 415 });
  if (req.headers['content-encoding'] && req.headers['content-encoding'] !== 'identity') throw new BridgeError('Compressed bodies are unsupported', { status: 415 });
  if (Number(req.headers['content-length']) > limit) throw new BridgeError('Request too large', { status: 413 });
  let timer,bodySettled=false;
  const read = (async () => {
    let bytes = 0; const chunks = [];
    for await (const chunk of req) {
      bytes += chunk.length;
      if (bytes > limit) throw new BridgeError('Request too large', { status: 413 });
      chunks.push(chunk);
    }
    return Buffer.concat(chunks);
  })();
  const timeout = new Promise((_, reject) => { timer = setTimeout(() => { if(bodySettled)return;reject(new BridgeError('Body timeout', { status: 408 })); req.destroy(); }, 10000); });
  try { return await Promise.race([read, timeout]); } finally { bodySettled=true;clearTimeout(timer); }
}
function parse(body) {
  try { return JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(body)); }
  catch { throw new BridgeError('Invalid JSON or UTF-8', { code: -32700 }); }
}
function decodedName(value) {
  if (typeof value !== 'string') return value;
  if (!value.startsWith('=?base64?')) return value;
  const match = /^=\?base64\?([A-Za-z0-9+/]+={0,2})\?=$/.exec(value);
  if (!match) return undefined;
  const bytes = Buffer.from(match[1], 'base64');
  if (bytes.toString('base64') !== match[1]) return undefined;
  try { return new TextDecoder('utf8', { fatal: true }).decode(bytes); } catch { return undefined; }
}
export function validateMcp(request, headers) {
  object(request, ['jsonrpc', 'id', 'method', 'params'], ['jsonrpc', 'method']);
  if (request.jsonrpc !== '2.0' || typeof request.method !== 'string' ||
      (Object.hasOwn(request, 'id') && !(typeof request.id === 'string' || (typeof request.id === 'number' && Number.isFinite(request.id))))) {
    throw new BridgeError('Invalid JSON-RPC request', { code: -32600 });
  }
  const params = request.params ?? {}, meta = params._meta;
  if (!params || typeof params !== 'object' || Array.isArray(params) || !meta || typeof meta !== 'object' || Array.isArray(meta) ||
      typeof meta['io.modelcontextprotocol/protocolVersion'] !== 'string' || !meta['io.modelcontextprotocol/clientCapabilities'] ||
      typeof meta['io.modelcontextprotocol/clientCapabilities'] !== 'object' || Array.isArray(meta['io.modelcontextprotocol/clientCapabilities'])) {
    throw new BridgeError('Required per-request MCP metadata is missing');
  }
  const version = meta['io.modelcontextprotocol/protocolVersion'];
  if (headers['mcp-protocol-version'] !== version || headers['mcp-method'] !== request.method ||
      (['tools/call', 'resources/read', 'prompts/get'].includes(request.method) && decodedName(headers['mcp-name']) !== (params.name ?? params.uri))) {
    throw new BridgeError('MCP header/body mismatch or required header missing', { code: -32020 });
  }
  if (version !== VERSION) throw new BridgeError('Unsupported MCP protocol version', { code: -32022, data: { supported: [VERSION] } });
  const accept = headers.accept ?? '';
  if (!accept.includes('application/json') || !accept.includes('text/event-stream')) throw new BridgeError('Accept must include application/json and text/event-stream', { status: 406 });
  return params;
}

export function createApp(config, { clock = Date.now, send = makePublicRequester(), worker = true, sdk, approvedLive = false, report = () => {} } = {}) {
  if (config.authMode === 'tunnel-service') assertTunnelServiceConfig(config);
  if (tunnelLive(config) && !approvedLive) throw new Error('Explicit live startup approval required');
  if (tunnelReadiness(config) && config.dbPath !== ':memory:') throw new Error('Tunnel readiness requires an ephemeral empty store');
  if (config.bridgeMode === 'sites') throw new Error('Sites mode cannot start the local MCP server');
  if (tunnelLive(config)) assertLiveStorage(config);
  const authenticate = createAuthenticator(config, send, clock);
  const bridge = new Bridge(config, { clock, send });
  let interval, lastTick = Promise.resolve(), stopping = false, lastPrune = 0;
  const larkRuntime = createLarkRuntime(config, bridge.store, clock, { sdk, report, send, isStopping: () => stopping });
  bridge.gatewayConnected=()=>{const state=larkRuntime.status();return ['disabled','connecting','reconnecting','connected','failed','idle'].includes(state)?state==='connected':undefined;};
  const readiness = () => {
    const configured = bridge.ready(), subscribed = !!bridge.store.activeSubscription(clock()), connected = larkRuntime.status() === 'connected';
    return { callback_transport: bridge.callbackTransportStatus(), bridge_configuration_ready: configured, mcp_subscription_active: subscribed, gateway_connected: connected,
      ready_for_delivery: configured && subscribed && connected, end_to_end_verified: false };
  };
  const ready = () => readiness().ready_for_delivery;
  const server = http.createServer(async (req, res) => {
    let rpcId, isMcp = false;
    try {
      const url = new URL(req.url, 'http://bridge.invalid');
      const hostname = new URL(`http://${req.headers.host}`).hostname;
      const hosts = ['127.0.0.1', 'localhost', '[::1]', config.host];
      if (config.publicOrigin) hosts.push(new URL(config.publicOrigin).hostname);
      if (!hosts.includes(hostname)) throw new BridgeError('Invalid Host', { status: 403 });
      if (req.method === 'GET' && url.pathname === '/healthz') return json(res, 200, { status: 'ok', bridge_ready: ready() });
      if (req.method === 'GET' && url.pathname === '/readyz') {
        const active = ready();
        return json(res, active ? 200 : 503, { ready: active, lark_transport: larkRuntime.status(), ...readiness() });
      }
      if (req.method === 'GET' && ['/.well-known/oauth-protected-resource', '/.well-known/oauth-protected-resource/mcp'].includes(url.pathname)) {
        if (config.authMode !== 'oauth') return json(res, 404, { error: 'OAuth is not configured' });
        return json(res, 200, { resource: config.oauthAudience, authorization_servers: [config.oauthIssuer],
          scopes_supported: [config.oauthScope], bearer_methods_supported: ['header'] });
      }
      if (url.pathname === '/mcp') {
        isMcp = true;
        if (req.method !== 'POST') return json(res, 405, { error: 'POST required' }, { Allow: 'POST' });
        if (req.headers.origin !== undefined && !config.allowedOrigins.includes(req.headers.origin)) throw new BridgeError('Invalid Origin', { status: 403, code: -32012 });
        const principal = await authenticate(req);
        const request = parse(await readBody(req));
        rpcId = request && !Array.isArray(request) ? request.id : undefined;
        const params = validateMcp(request, req.headers);
        bridge.store.tx(() => bridge.store.rate('mcp', 120, clock()));
        if (!Object.hasOwn(request, 'id')) {
          if (request.method !== 'notifications/cancelled') throw new BridgeError('Unsupported notification');
          res.writeHead(202); res.end(); return;
        }
        const result = await bridge.rpc(request.method, params, principal);
        return json(res, 200, rpcResult(request.id, result));
      }
      return json(res, 404, { error: 'Not found' });
    } catch (error) {
      const safe = error instanceof BridgeError ? error : new BridgeError('Internal bridge error', { status: 500, code: -32603 });
      const extra = safe.status === 401 && isMcp ? { 'WWW-Authenticate': config.authMode === 'oauth' ?
        `Bearer resource_metadata="${config.publicOrigin}/.well-known/oauth-protected-resource/mcp", scope="${config.oauthScope}"` : config.authMode === 'tunnel-service' ? 'DotBridgeService' : 'Bearer' } : {};
      if (!res.headersSent && !res.destroyed) json(res, safe.status, isMcp ? { jsonrpc: '2.0', id: rpcId ?? null,
        error: { code: safe.code, message: safe.message, ...(safe.data ? { data: safe.data } : {}) } } : { error: safe.message }, extra);
    }
  });
  server.headersTimeout = 10000; server.requestTimeout = 15000; server.timeout = config.interaction?.enabled?60000:30000;
  server.keepAliveTimeout = 5000; server.maxConnections = 64;
  let feedbackTick=Promise.resolve(),feedbackInterval;
  function runFeedback(){if(stopping||bridge.interactions.feedbackRunning)return;feedbackTick=bridge.interactions.tickFeedback().catch(()=>{report('lark_sdk_warning');});}
  function runWorker() {
    if (stopping || bridge.running) return;
    lastTick = Promise.resolve(larkRuntime.syncSubscription()).then(() => bridge.tick()).then(() => {
      if (clock() - lastPrune > 3600000) { bridge.store.prune(clock()); lastPrune = clock(); }
    }).catch(() => { process.stderr.write('Worker failure; inspect durable queue using the operator runbook.\n'); });
  }
  let closing, listening = false, listenSettled;
  return { server, bridge, larkRuntime, readiness,
    async listen(port = config.port, host = config.host) {
      if (stopping || closing || listening) throw new Error('Listener cannot restart or start twice');
      listening = true;
      if (config.authMode === 'tunnel-service' && !['127.0.0.1', '::1'].includes(host)) throw new Error('Tunnel service listener must be loopback');
      listenSettled = new Promise((resolve, reject) => { server.once('error', reject); server.listen(port, host, resolve); });
      await listenSettled;
      if (stopping) return server.address();
      if (worker && !tunnelReadiness(config)) { interval = setInterval(runWorker, config.workerIntervalMs); interval.unref(); feedbackInterval=setInterval(runFeedback,config.workerIntervalMs);feedbackInterval.unref(); }
      await larkRuntime.start();
      return server.address();
    },
    async close() {
      if (!closing) closing = (async () => {
        stopping = true; clearInterval(interval);clearInterval(feedbackInterval); larkRuntime.close();
        await listenSettled?.catch(() => {});
        await new Promise(resolve => server.close(resolve));
        await lastTick;await feedbackTick; bridge.store.close();
      })();
      return closing;
    }
  };
}
