import {createSilkDecoder} from '@dot-bridge/core/audio/silk.js';
import {isSilk} from 'silk-wasm';
import {MAX_MEDIA_BYTES,MAX_MEDIA_BASE64} from '@dot-bridge/core/channels/media.js';
import { BridgeError, plainText } from './common.js';
import { destinationUrl } from './network.js';
import { QQ_MEDIA_HOSTS } from './provider-network.js';

export const QQ_AUDIO_BYTES = MAX_MEDIA_BYTES;
export const QQ_AUDIO_BASE64 = MAX_MEDIA_BASE64;
export const QQ_AUDIO_DURATION_MS = 120000;
export const QQ_AUDIO_MIMES = Object.freeze(['audio/wav', 'audio/mpeg', 'audio/ogg']);

// URLs originate only in authenticated owner events. They are never tool inputs,
// callback destinations, or places to send the bot's Authorization header.
export function voiceUrl(raw) {
  if (typeof raw !== 'string' || !raw || raw.length > 4096 || /[\s\u0000-\u001f\u007f]/u.test(raw)) throw new BridgeError('Invalid QQ voice resource');
  return destinationUrl(raw.startsWith('//') ? `https:${raw}` : raw, QQ_MEDIA_HOSTS).href;
}

export function incomingVoice(attachments) {
  if (attachments === undefined || (Array.isArray(attachments) && !attachments.length)) return [];
  if (!Array.isArray(attachments) || attachments.length !== 1) return null;
  const item = attachments[0];
  if (!item || typeof item !== 'object' || Array.isArray(item)) return null;
  const mime = typeof item.content_type === 'string' ? item.content_type.toLowerCase() : '';
  const extension = typeof item.filename === 'string' && /\.(silk|slk|slac|amr)$/i.test(item.filename);
  if (!(mime === 'voice' || mime.startsWith('audio/') || (mime === 'application/octet-stream' && extension))) return null;
  // Invalid or unsupported download links must not silence an otherwise valid
  // voice event. The dot can still use QQ's optional reference transcription.
  const urls = [];
  for (const raw of [item.voice_wav_url, item.url]) {
    if (!raw) continue;
    try { const url = voiceUrl(raw); if (!urls.includes(url)) urls.push(url); } catch { /* fail closed on this resource */ }
  }
  let transcript = null;
  if (typeof item.asr_refer_text === 'string' && item.asr_refer_text.trim()) {
    try { transcript = plainText(item.asr_refer_text.trim()); } catch { /* never trust malformed ASR */ }
  }
  return [{ type: 'audio', urls, transcript }];
}

export function voiceMetadata(items = []) {
  return items.map((item, index) => ({ index, type: 'audio', transcript: item.transcript ?? null, audio_available: item.urls.length > 0 }));
}

export function audioMime(bytes) {
  if (bytes.length >= 44 && bytes.toString('ascii', 0, 4) === 'RIFF' && bytes.toString('ascii', 8, 12) === 'WAVE') return 'audio/wav';
  if (bytes.length >= 4 && (bytes.toString('ascii', 0, 3) === 'ID3' || (bytes[0] === 255 && (bytes[1] & 224) === 224))) return 'audio/mpeg';
  if (bytes.length >= 32 && bytes.toString('ascii', 0, 4) === 'OggS' &&
      (bytes.subarray(0,256).includes(Buffer.from('OpusHead')) || bytes.subarray(0,256).includes(Buffer.from('vorbis')))) return 'audio/ogg';
  return null;
}

const decodeSilk=createSilkDecoder(import.meta.resolve('silk-wasm'));
export async function decodeVoice(input,options={}) {
  if (!Buffer.isBuffer(input) || !input.length || input.length > QQ_AUDIO_BYTES) throw new BridgeError('QQ voice size refused');
  const mime = audioMime(input);
  if (mime) return { bytes: Buffer.from(input), mime };
  // A worker isolates the decoder from the gateway heartbeat and can be stopped
  // on timeout. No media file, shell command, model API or persistent key is used.
  try{return{bytes:await decodeSilk(input,options),mime:'audio/wav'};}
  catch{throw new BridgeError('QQ voice format unavailable; use its reference transcript or ask the sender for text');}
}

export function createVoiceReader(send) {
  let active = 0;
  return async (message, index, authorize, {forReply=false}={}) => {
    authorize();
    const item = message.attachments?.[index];
    if (index !== 0 || !item || !item.urls.length) throw new BridgeError('QQ voice audio unavailable; use its reference transcript or ask the sender for text');
    if (active >= 2) throw new BridgeError('QQ voice reader busy; retry shortly', { status: 429, retryable: true });
    active++;
    try {
      for (const raw of item.urls) {
        let input, decoded;
        try {
          const url = voiceUrl(raw);
          authorize();
          const response = await (send.resourceRequester ?? send)(url, {
            method: 'GET', purpose: 'provider', hosts: QQ_MEDIA_HOSTS,
            headers: { 'Accept-Encoding': 'identity' }, body: Buffer.alloc(0), beforeConnect: authorize
          });
          input = response.body;
          authorize();
          if (response.status !== 200 || (response.headers?.['content-encoding'] && response.headers['content-encoding'] !== 'identity')) throw new BridgeError('QQ voice resource unavailable');
          if(forReply){
            if(!Buffer.isBuffer(input)||!input.length||input.length>QQ_AUDIO_BYTES)throw new BridgeError('QQ voice size refused');
            const payload=input.subarray(input.toString('ascii',0,6)==='#!AMR\n'?6:0);
            const mime=audioMime(input)??(isSilk(payload)?'audio/silk':null);
            if(!mime)throw new BridgeError('QQ source audio format unavailable');
            if(mime==='audio/silk'){
              const check=await decodeVoice(payload);try{authorize();}finally{check.bytes.fill(0);}
            }
            decoded={bytes:Buffer.from(mime==='audio/silk'?payload:input),mime};
          }else decoded = await decodeVoice(input);
          authorize();
          return decoded;
        } catch (error) {
          decoded?.bytes.fill(0);
          if (error?.code === -32012) throw error;
        } finally { input?.fill(0); }
      }
      throw new BridgeError('QQ voice audio unavailable; use its reference transcript or ask the sender to resend or send text');
    } finally { active--; }
  };
}
