export const channel = Object.freeze({"id": "dingtalk", "name": "钉钉", "envPrefix": "DINGTALK", "defaultPort": 8790, "maxReplyText": 600,
  maxMediaReplyText: 0, media: Object.freeze({ read: ['image', 'audio', 'file'], reply: ['image', 'audio', 'file'] })});
