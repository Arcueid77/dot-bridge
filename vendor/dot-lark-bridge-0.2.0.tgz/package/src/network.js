import { checkedOptions, normalizeRequesterOptions } from './requester-options.js';
import { makeCallbackTransport, projectCallbackTransportStatus, TRANSPORT_ERROR_CODES } from '@dot-bridge/core/transport';
import { configuredProviderProxy, makeProviderRequester } from './provider-network.js';
import https from 'node:https';
import { lookup as dnsLookup } from 'node:dns/promises';
import { isIP } from 'node:net';
import { BridgeError } from './common.js';

const fail = (message, reason = 'connection_refused') => new BridgeError(message, { code: -32015, data: { reason }, retryable: true });
export function publicAddress(address) {
  if (isIP(address) === 4) {
    const [a, b, c] = address.split('.').map(Number);
    return !(a === 0 || a === 10 || a === 127 || a >= 224 ||
      (a === 100 && b >= 64 && b <= 127) || (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && ((b === 0 && (c === 0 || c === 2)) || b === 168 || (b === 88 && c === 99))) ||
      (a === 198 && (b === 18 || b === 19 || (b === 51 && c === 100))) || (a === 203 && b === 0 && c === 113));
  }
  if (isIP(address) === 6) {
    const normalized = address.toLowerCase(), first = Number.parseInt(normalized.split(':')[0], 16);
    // Accept the global-unicast allocation only; reject transition/documentation blocks.
    return first >= 0x2000 && first <= 0x3fff && !normalized.includes('.') &&
      !normalized.startsWith('2002:') && !normalized.startsWith('3fff:') &&
      !(first === 0x2001 && (Number.parseInt(normalized.split(':')[1] || '0', 16) < 0x200 || Number.parseInt(normalized.split(':')[1] || '0', 16) === 0xdb8));
  }
  return false;
}
export function destinationUrl(raw, hosts) {
  let url;
  try { url = new URL(raw); } catch { throw new BridgeError('Malformed callback URL'); }
  if (url.protocol !== 'https:' || url.username || url.password || url.hash || (url.port && url.port !== '443') ||
      !hosts.includes(url.hostname) || url.hostname.endsWith('.') || isIP(url.hostname.replace(/^\[|\]$/g, ''))) {
    throw new BridgeError('Destination must be HTTPS on an explicitly allowed hostname');
  }
  return url;
}
export async function resolveDestination(raw, hosts, lookup = dnsLookup) {
  const url = destinationUrl(raw, hosts);
  const answers = await lookup(url.hostname, { all: true, verbatim: true });
  if (!answers.length || answers.length > 32 || answers.some(answer => !publicAddress(answer.address) || isIP(answer.address) !== answer.family)) {
    throw fail('Destination has a non-public address');
  }
  return { url, answers };
}
export function makePublicRequester(options = {}) {
  const { lookup = dnsLookup, request = https.request, timeoutMs = 10000, maxBytes = 262144, proxyEnv = process.env, providerTimeoutMs = 30000,
    providerSend = makeProviderRequester({ env: proxyEnv, timeoutMs: providerTimeoutMs, maxBytes }), callbackTransport, managedAdapter,
    callbackTimeoutMs = 10000, callbackMaxBytes = 8192 } = normalizeRequesterOptions(options);
  const callback = callbackTransport ?? makeCallbackTransport({ lookup, request, timeoutMs: callbackTimeoutMs, maxBytes: callbackMaxBytes, proxyEnv, managedAdapter });
  const send = async function send(raw, { method = 'POST', headers = {}, body = Buffer.alloc(0), hosts, beforeConnect = () => {}, purpose, signal }) {
    if (purpose === 'callback') {
      let cancelled = false;
      const gate = () => {
        const rejectGate = error => { cancelled = error instanceof BridgeError && error.code === -32012; throw error; };
        try {
          const result = beforeConnect();
          return result && typeof result.then === 'function' ? result.then(undefined, rejectGate) : result;
        } catch (error) { return rejectGate(error); }
      };
      try { return await callback(raw, { method, headers, body, hosts, beforeConnect: gate, signal }); }
      catch (error) {
        if(error?.code==='delivery_uncertain')throw new BridgeError('Callback delivery acknowledgement unknown',{code:-32015,uncertain:true,data:{reason:'delivery_uncertain',callback_transport:callbackTransportStatus(send)}});
        if (cancelled || (error instanceof BridgeError && error.code === -32012)) throw new BridgeError('Callback operation cancelled', { code: -32012 });
        const reason = TRANSPORT_ERROR_CODES.includes(error?.code) ? error.code : 'connection_failed';
        throw new BridgeError('Callback transport rejected', { code: -32015, data: { reason, callback_transport: callbackTransportStatus(send) }, retryable: ['dns_failed','timeout','connection_failed'].includes(reason) });
      }
    }
    if (purpose === 'provider' && configuredProviderProxy(proxyEnv)) return providerSend(raw, { method, headers, body, hosts, beforeConnect, signal });
    // The DNS check is repeated on EVERY attempt; the vetted answers are pinned in lookup.
    let timer;
    const timeout = new Promise((_, reject) => { timer = setTimeout(() => reject(fail('Destination timeout', 'timeout')), timeoutMs); });
    let destination;
    try { destination = await Promise.race([resolveDestination(raw, hosts, lookup), timeout]); }
    finally { clearTimeout(timer); }
    const { url, answers } = destination;
    beforeConnect();
    return new Promise((resolve, reject) => {
      const req = request(url, { method, headers: { ...headers, 'Content-Length': body.length }, agent: false,
        lookup: (_hostname, options, callback) => options.all ? callback(null, answers) : callback(null, answers[0].address, answers[0].family),
        servername: url.hostname, rejectUnauthorized: true, signal }, res => {
        const chunks = [];
        let size = 0;
        res.on('data', chunk => {
          size += chunk.length;
          if (size > maxBytes) res.destroy(fail('Response too large', 'http_4xx'));
          else chunks.push(chunk);
        });
        res.on('error', reject);
        res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks) }));
      });
      const deadline = setTimeout(() => req.destroy(fail('Destination timeout', 'timeout')), timeoutMs);
      req.on('close', () => clearTimeout(deadline));
      req.on('error', error => reject(error instanceof BridgeError ? error : fail('Destination connection failed', error.code?.startsWith('ERR_TLS') || error.code?.includes('CERT') ? 'tls_error' : 'connection_refused')));
      req.end(body);
    });
  };
  send.callbackTransportStatus = () => {
    try { return safeCallbackTransportStatus(typeof callback.preflight === 'function' ? callback.preflight() : undefined); } catch { return safeCallbackTransportStatus(undefined); }
  };
  send.callbackPreflight = send.callbackTransportStatus;
  return send;
}

export function callbackTransportStatus(send) {
  try { return safeCallbackTransportStatus(typeof send?.callbackTransportStatus === 'function' ? send.callbackTransportStatus() : undefined); } catch { return safeCallbackTransportStatus(undefined); }
}
export { TRANSPORT_ERROR_CODES };

export function safeCallbackTransportStatus(value) {
  try { return projectCallbackTransportStatus(value); } catch { return { ready: false, mode: 'blocked', reason: 'transport_unverified', proxy_configured: null, destination_binding: 'unverified', network_checked: false }; }
}

// A launcher may supply a reviewed code factory, never a module name from env.
// Construct once and pass the returned sender to both preflight and service.
export function createServiceSender(options = {}) {
  const { proxyEnv = process.env, requesterFactory = makePublicRequester } = checkedOptions(options, ['proxyEnv', 'requesterFactory'], 'Invalid service sender options');
  if (typeof requesterFactory !== 'function') throw new TypeError('Invalid service requester factory');
  const send = requesterFactory({ proxyEnv });
  if (typeof send !== 'function') throw new TypeError('Invalid service sender');
  return send;
}
